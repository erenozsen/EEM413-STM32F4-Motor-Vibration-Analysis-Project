Core/Src/ff.o: ../Core/Src/ff.c ../Core/Inc/ff.h ../Core/Inc/integer.h \
 ../Core/Inc/ffconf.h ../Core/Inc/diskio.h ../Core/Inc/defines.h \
 ../Core/Inc/attributes.h
../Core/Inc/ff.h:
../Core/Inc/integer.h:
../Core/Inc/ffconf.h:
../Core/Inc/diskio.h:
../Core/Inc/defines.h:
../Core/Inc/attributes.h:
