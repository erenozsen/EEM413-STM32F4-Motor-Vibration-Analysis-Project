################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/main.c \
../Core/Src/stm32f4xx_hal_msp.c \
../Core/Src/stm32f4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32f4xx.c \
../Core/Src/tm_stm32_delay.c \
../Core/Src/tm_stm32_disco.c \
../Core/Src/tm_stm32_gpio.c \
../Core/Src/tm_stm32_lis302dl_lis3dsh.c \
../Core/Src/tm_stm32_rcc.c \
../Core/Src/tm_stm32_spi.c 

OBJS += \
./Core/Src/main.o \
./Core/Src/stm32f4xx_hal_msp.o \
./Core/Src/stm32f4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32f4xx.o \
./Core/Src/tm_stm32_delay.o \
./Core/Src/tm_stm32_disco.o \
./Core/Src/tm_stm32_gpio.o \
./Core/Src/tm_stm32_lis302dl_lis3dsh.o \
./Core/Src/tm_stm32_rcc.o \
./Core/Src/tm_stm32_spi.o 

C_DEPS += \
./Core/Src/main.d \
./Core/Src/stm32f4xx_hal_msp.d \
./Core/Src/stm32f4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32f4xx.d \
./Core/Src/tm_stm32_delay.d \
./Core/Src/tm_stm32_disco.d \
./Core/Src/tm_stm32_gpio.d \
./Core/Src/tm_stm32_lis302dl_lis3dsh.d \
./Core/Src/tm_stm32_rcc.d \
./Core/Src/tm_stm32_spi.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../USB_HOST/App -I../USB_HOST/Target -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/ST/STM32_USB_Host_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Host_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/stm32f4xx_hal_msp.cyclo ./Core/Src/stm32f4xx_hal_msp.d ./Core/Src/stm32f4xx_hal_msp.o ./Core/Src/stm32f4xx_hal_msp.su ./Core/Src/stm32f4xx_it.cyclo ./Core/Src/stm32f4xx_it.d ./Core/Src/stm32f4xx_it.o ./Core/Src/stm32f4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32f4xx.cyclo ./Core/Src/system_stm32f4xx.d ./Core/Src/system_stm32f4xx.o ./Core/Src/system_stm32f4xx.su ./Core/Src/tm_stm32_delay.cyclo ./Core/Src/tm_stm32_delay.d ./Core/Src/tm_stm32_delay.o ./Core/Src/tm_stm32_delay.su ./Core/Src/tm_stm32_disco.cyclo ./Core/Src/tm_stm32_disco.d ./Core/Src/tm_stm32_disco.o ./Core/Src/tm_stm32_disco.su ./Core/Src/tm_stm32_gpio.cyclo ./Core/Src/tm_stm32_gpio.d ./Core/Src/tm_stm32_gpio.o ./Core/Src/tm_stm32_gpio.su ./Core/Src/tm_stm32_lis302dl_lis3dsh.cyclo ./Core/Src/tm_stm32_lis302dl_lis3dsh.d ./Core/Src/tm_stm32_lis302dl_lis3dsh.o ./Core/Src/tm_stm32_lis302dl_lis3dsh.su ./Core/Src/tm_stm32_rcc.cyclo ./Core/Src/tm_stm32_rcc.d ./Core/Src/tm_stm32_rcc.o ./Core/Src/tm_stm32_rcc.su ./Core/Src/tm_stm32_spi.cyclo ./Core/Src/tm_stm32_spi.d ./Core/Src/tm_stm32_spi.o ./Core/Src/tm_stm32_spi.su

.PHONY: clean-Core-2f-Src

