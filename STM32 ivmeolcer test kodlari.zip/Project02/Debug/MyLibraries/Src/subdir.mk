################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../MyLibraries/Src/tm_stm32_adc.c \
../MyLibraries/Src/tm_stm32_ahrs_imu.c \
../MyLibraries/Src/tm_stm32_am2301.c \
../MyLibraries/Src/tm_stm32_bmp180.c \
../MyLibraries/Src/tm_stm32_bor.c \
../MyLibraries/Src/tm_stm32_buffer.c \
../MyLibraries/Src/tm_stm32_button.c \
../MyLibraries/Src/tm_stm32_cpu_load.c \
../MyLibraries/Src/tm_stm32_crc.c \
../MyLibraries/Src/tm_stm32_dac.c \
../MyLibraries/Src/tm_stm32_delay.c \
../MyLibraries/Src/tm_stm32_disco.c \
../MyLibraries/Src/tm_stm32_dma.c \
../MyLibraries/Src/tm_stm32_dma2d_graphic.c \
../MyLibraries/Src/tm_stm32_ds18b20.c \
../MyLibraries/Src/tm_stm32_exti.c \
../MyLibraries/Src/tm_stm32_fatfs.c \
../MyLibraries/Src/tm_stm32_fft.c \
../MyLibraries/Src/tm_stm32_filters.c \
../MyLibraries/Src/tm_stm32_fonts.c \
../MyLibraries/Src/tm_stm32_general.c \
../MyLibraries/Src/tm_stm32_gpio.c \
../MyLibraries/Src/tm_stm32_gps.c \
../MyLibraries/Src/tm_stm32_hd44780.c \
../MyLibraries/Src/tm_stm32_i2c.c \
../MyLibraries/Src/tm_stm32_i2c_dma.c \
../MyLibraries/Src/tm_stm32_id.c \
../MyLibraries/Src/tm_stm32_iwdg.c \
../MyLibraries/Src/tm_stm32_lcd.c \
../MyLibraries/Src/tm_stm32_library_template.c \
../MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.c \
../MyLibraries/Src/tm_stm32_mpu6050.c \
../MyLibraries/Src/tm_stm32_mpu9250.c \
../MyLibraries/Src/tm_stm32_nrf24l01.c \
../MyLibraries/Src/tm_stm32_onewire.c \
../MyLibraries/Src/tm_stm32_pvd.c \
../MyLibraries/Src/tm_stm32_qspiflash.c \
../MyLibraries/Src/tm_stm32_rcc.c \
../MyLibraries/Src/tm_stm32_rng.c \
../MyLibraries/Src/tm_stm32_rotary_encoder.c \
../MyLibraries/Src/tm_stm32_rtc.c \
../MyLibraries/Src/tm_stm32_sdram.c \
../MyLibraries/Src/tm_stm32_spi.c \
../MyLibraries/Src/tm_stm32_spi_dma.c \
../MyLibraries/Src/tm_stm32_ssd1306.c \
../MyLibraries/Src/tm_stm32_string.c \
../MyLibraries/Src/tm_stm32_touch.c \
../MyLibraries/Src/tm_stm32_touch_ft5336.c \
../MyLibraries/Src/tm_stm32_touch_ts3510.c \
../MyLibraries/Src/tm_stm32_usart.c \
../MyLibraries/Src/tm_stm32_usart_dma.c \
../MyLibraries/Src/tm_stm32_usb.c \
../MyLibraries/Src/tm_stm32_usb_device.c \
../MyLibraries/Src/tm_stm32_usb_device_cdc.c \
../MyLibraries/Src/tm_stm32_usb_device_msc.c \
../MyLibraries/Src/tm_stm32_usb_host.c \
../MyLibraries/Src/tm_stm32_usb_host_hid.c \
../MyLibraries/Src/tm_stm32_usb_host_msc.c 

OBJS += \
./MyLibraries/Src/tm_stm32_adc.o \
./MyLibraries/Src/tm_stm32_ahrs_imu.o \
./MyLibraries/Src/tm_stm32_am2301.o \
./MyLibraries/Src/tm_stm32_bmp180.o \
./MyLibraries/Src/tm_stm32_bor.o \
./MyLibraries/Src/tm_stm32_buffer.o \
./MyLibraries/Src/tm_stm32_button.o \
./MyLibraries/Src/tm_stm32_cpu_load.o \
./MyLibraries/Src/tm_stm32_crc.o \
./MyLibraries/Src/tm_stm32_dac.o \
./MyLibraries/Src/tm_stm32_delay.o \
./MyLibraries/Src/tm_stm32_disco.o \
./MyLibraries/Src/tm_stm32_dma.o \
./MyLibraries/Src/tm_stm32_dma2d_graphic.o \
./MyLibraries/Src/tm_stm32_ds18b20.o \
./MyLibraries/Src/tm_stm32_exti.o \
./MyLibraries/Src/tm_stm32_fatfs.o \
./MyLibraries/Src/tm_stm32_fft.o \
./MyLibraries/Src/tm_stm32_filters.o \
./MyLibraries/Src/tm_stm32_fonts.o \
./MyLibraries/Src/tm_stm32_general.o \
./MyLibraries/Src/tm_stm32_gpio.o \
./MyLibraries/Src/tm_stm32_gps.o \
./MyLibraries/Src/tm_stm32_hd44780.o \
./MyLibraries/Src/tm_stm32_i2c.o \
./MyLibraries/Src/tm_stm32_i2c_dma.o \
./MyLibraries/Src/tm_stm32_id.o \
./MyLibraries/Src/tm_stm32_iwdg.o \
./MyLibraries/Src/tm_stm32_lcd.o \
./MyLibraries/Src/tm_stm32_library_template.o \
./MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.o \
./MyLibraries/Src/tm_stm32_mpu6050.o \
./MyLibraries/Src/tm_stm32_mpu9250.o \
./MyLibraries/Src/tm_stm32_nrf24l01.o \
./MyLibraries/Src/tm_stm32_onewire.o \
./MyLibraries/Src/tm_stm32_pvd.o \
./MyLibraries/Src/tm_stm32_qspiflash.o \
./MyLibraries/Src/tm_stm32_rcc.o \
./MyLibraries/Src/tm_stm32_rng.o \
./MyLibraries/Src/tm_stm32_rotary_encoder.o \
./MyLibraries/Src/tm_stm32_rtc.o \
./MyLibraries/Src/tm_stm32_sdram.o \
./MyLibraries/Src/tm_stm32_spi.o \
./MyLibraries/Src/tm_stm32_spi_dma.o \
./MyLibraries/Src/tm_stm32_ssd1306.o \
./MyLibraries/Src/tm_stm32_string.o \
./MyLibraries/Src/tm_stm32_touch.o \
./MyLibraries/Src/tm_stm32_touch_ft5336.o \
./MyLibraries/Src/tm_stm32_touch_ts3510.o \
./MyLibraries/Src/tm_stm32_usart.o \
./MyLibraries/Src/tm_stm32_usart_dma.o \
./MyLibraries/Src/tm_stm32_usb.o \
./MyLibraries/Src/tm_stm32_usb_device.o \
./MyLibraries/Src/tm_stm32_usb_device_cdc.o \
./MyLibraries/Src/tm_stm32_usb_device_msc.o \
./MyLibraries/Src/tm_stm32_usb_host.o \
./MyLibraries/Src/tm_stm32_usb_host_hid.o \
./MyLibraries/Src/tm_stm32_usb_host_msc.o 

C_DEPS += \
./MyLibraries/Src/tm_stm32_adc.d \
./MyLibraries/Src/tm_stm32_ahrs_imu.d \
./MyLibraries/Src/tm_stm32_am2301.d \
./MyLibraries/Src/tm_stm32_bmp180.d \
./MyLibraries/Src/tm_stm32_bor.d \
./MyLibraries/Src/tm_stm32_buffer.d \
./MyLibraries/Src/tm_stm32_button.d \
./MyLibraries/Src/tm_stm32_cpu_load.d \
./MyLibraries/Src/tm_stm32_crc.d \
./MyLibraries/Src/tm_stm32_dac.d \
./MyLibraries/Src/tm_stm32_delay.d \
./MyLibraries/Src/tm_stm32_disco.d \
./MyLibraries/Src/tm_stm32_dma.d \
./MyLibraries/Src/tm_stm32_dma2d_graphic.d \
./MyLibraries/Src/tm_stm32_ds18b20.d \
./MyLibraries/Src/tm_stm32_exti.d \
./MyLibraries/Src/tm_stm32_fatfs.d \
./MyLibraries/Src/tm_stm32_fft.d \
./MyLibraries/Src/tm_stm32_filters.d \
./MyLibraries/Src/tm_stm32_fonts.d \
./MyLibraries/Src/tm_stm32_general.d \
./MyLibraries/Src/tm_stm32_gpio.d \
./MyLibraries/Src/tm_stm32_gps.d \
./MyLibraries/Src/tm_stm32_hd44780.d \
./MyLibraries/Src/tm_stm32_i2c.d \
./MyLibraries/Src/tm_stm32_i2c_dma.d \
./MyLibraries/Src/tm_stm32_id.d \
./MyLibraries/Src/tm_stm32_iwdg.d \
./MyLibraries/Src/tm_stm32_lcd.d \
./MyLibraries/Src/tm_stm32_library_template.d \
./MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.d \
./MyLibraries/Src/tm_stm32_mpu6050.d \
./MyLibraries/Src/tm_stm32_mpu9250.d \
./MyLibraries/Src/tm_stm32_nrf24l01.d \
./MyLibraries/Src/tm_stm32_onewire.d \
./MyLibraries/Src/tm_stm32_pvd.d \
./MyLibraries/Src/tm_stm32_qspiflash.d \
./MyLibraries/Src/tm_stm32_rcc.d \
./MyLibraries/Src/tm_stm32_rng.d \
./MyLibraries/Src/tm_stm32_rotary_encoder.d \
./MyLibraries/Src/tm_stm32_rtc.d \
./MyLibraries/Src/tm_stm32_sdram.d \
./MyLibraries/Src/tm_stm32_spi.d \
./MyLibraries/Src/tm_stm32_spi_dma.d \
./MyLibraries/Src/tm_stm32_ssd1306.d \
./MyLibraries/Src/tm_stm32_string.d \
./MyLibraries/Src/tm_stm32_touch.d \
./MyLibraries/Src/tm_stm32_touch_ft5336.d \
./MyLibraries/Src/tm_stm32_touch_ts3510.d \
./MyLibraries/Src/tm_stm32_usart.d \
./MyLibraries/Src/tm_stm32_usart_dma.d \
./MyLibraries/Src/tm_stm32_usb.d \
./MyLibraries/Src/tm_stm32_usb_device.d \
./MyLibraries/Src/tm_stm32_usb_device_cdc.d \
./MyLibraries/Src/tm_stm32_usb_device_msc.d \
./MyLibraries/Src/tm_stm32_usb_host.d \
./MyLibraries/Src/tm_stm32_usb_host_hid.d \
./MyLibraries/Src/tm_stm32_usb_host_msc.d 


# Each subdirectory must supply rules for building sources it contributes
MyLibraries/Src/%.o MyLibraries/Src/%.su MyLibraries/Src/%.cyclo: ../MyLibraries/Src/%.c MyLibraries/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../USB_HOST/App -I"C:/ST/CubeMX_Projects/Project02/MyLibraries/Inc" -I"C:/ST/CubeMX_Projects/Project02/MyLibraries/Src" -I../USB_HOST/Target -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Middlewares/ST/STM32_USB_Host_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Host_Library/Class/CDC/Inc -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-MyLibraries-2f-Src

clean-MyLibraries-2f-Src:
	-$(RM) ./MyLibraries/Src/tm_stm32_adc.cyclo ./MyLibraries/Src/tm_stm32_adc.d ./MyLibraries/Src/tm_stm32_adc.o ./MyLibraries/Src/tm_stm32_adc.su ./MyLibraries/Src/tm_stm32_ahrs_imu.cyclo ./MyLibraries/Src/tm_stm32_ahrs_imu.d ./MyLibraries/Src/tm_stm32_ahrs_imu.o ./MyLibraries/Src/tm_stm32_ahrs_imu.su ./MyLibraries/Src/tm_stm32_am2301.cyclo ./MyLibraries/Src/tm_stm32_am2301.d ./MyLibraries/Src/tm_stm32_am2301.o ./MyLibraries/Src/tm_stm32_am2301.su ./MyLibraries/Src/tm_stm32_bmp180.cyclo ./MyLibraries/Src/tm_stm32_bmp180.d ./MyLibraries/Src/tm_stm32_bmp180.o ./MyLibraries/Src/tm_stm32_bmp180.su ./MyLibraries/Src/tm_stm32_bor.cyclo ./MyLibraries/Src/tm_stm32_bor.d ./MyLibraries/Src/tm_stm32_bor.o ./MyLibraries/Src/tm_stm32_bor.su ./MyLibraries/Src/tm_stm32_buffer.cyclo ./MyLibraries/Src/tm_stm32_buffer.d ./MyLibraries/Src/tm_stm32_buffer.o ./MyLibraries/Src/tm_stm32_buffer.su ./MyLibraries/Src/tm_stm32_button.cyclo ./MyLibraries/Src/tm_stm32_button.d ./MyLibraries/Src/tm_stm32_button.o ./MyLibraries/Src/tm_stm32_button.su ./MyLibraries/Src/tm_stm32_cpu_load.cyclo ./MyLibraries/Src/tm_stm32_cpu_load.d ./MyLibraries/Src/tm_stm32_cpu_load.o ./MyLibraries/Src/tm_stm32_cpu_load.su ./MyLibraries/Src/tm_stm32_crc.cyclo ./MyLibraries/Src/tm_stm32_crc.d ./MyLibraries/Src/tm_stm32_crc.o ./MyLibraries/Src/tm_stm32_crc.su ./MyLibraries/Src/tm_stm32_dac.cyclo ./MyLibraries/Src/tm_stm32_dac.d ./MyLibraries/Src/tm_stm32_dac.o ./MyLibraries/Src/tm_stm32_dac.su ./MyLibraries/Src/tm_stm32_delay.cyclo ./MyLibraries/Src/tm_stm32_delay.d ./MyLibraries/Src/tm_stm32_delay.o ./MyLibraries/Src/tm_stm32_delay.su ./MyLibraries/Src/tm_stm32_disco.cyclo ./MyLibraries/Src/tm_stm32_disco.d ./MyLibraries/Src/tm_stm32_disco.o ./MyLibraries/Src/tm_stm32_disco.su ./MyLibraries/Src/tm_stm32_dma.cyclo ./MyLibraries/Src/tm_stm32_dma.d ./MyLibraries/Src/tm_stm32_dma.o ./MyLibraries/Src/tm_stm32_dma.su ./MyLibraries/Src/tm_stm32_dma2d_graphic.cyclo ./MyLibraries/Src/tm_stm32_dma2d_graphic.d ./MyLibraries/Src/tm_stm32_dma2d_graphic.o ./MyLibraries/Src/tm_stm32_dma2d_graphic.su ./MyLibraries/Src/tm_stm32_ds18b20.cyclo ./MyLibraries/Src/tm_stm32_ds18b20.d ./MyLibraries/Src/tm_stm32_ds18b20.o ./MyLibraries/Src/tm_stm32_ds18b20.su ./MyLibraries/Src/tm_stm32_exti.cyclo ./MyLibraries/Src/tm_stm32_exti.d ./MyLibraries/Src/tm_stm32_exti.o ./MyLibraries/Src/tm_stm32_exti.su ./MyLibraries/Src/tm_stm32_fatfs.cyclo ./MyLibraries/Src/tm_stm32_fatfs.d ./MyLibraries/Src/tm_stm32_fatfs.o ./MyLibraries/Src/tm_stm32_fatfs.su ./MyLibraries/Src/tm_stm32_fft.cyclo ./MyLibraries/Src/tm_stm32_fft.d ./MyLibraries/Src/tm_stm32_fft.o ./MyLibraries/Src/tm_stm32_fft.su ./MyLibraries/Src/tm_stm32_filters.cyclo ./MyLibraries/Src/tm_stm32_filters.d ./MyLibraries/Src/tm_stm32_filters.o ./MyLibraries/Src/tm_stm32_filters.su ./MyLibraries/Src/tm_stm32_fonts.cyclo ./MyLibraries/Src/tm_stm32_fonts.d ./MyLibraries/Src/tm_stm32_fonts.o ./MyLibraries/Src/tm_stm32_fonts.su ./MyLibraries/Src/tm_stm32_general.cyclo ./MyLibraries/Src/tm_stm32_general.d ./MyLibraries/Src/tm_stm32_general.o ./MyLibraries/Src/tm_stm32_general.su ./MyLibraries/Src/tm_stm32_gpio.cyclo ./MyLibraries/Src/tm_stm32_gpio.d ./MyLibraries/Src/tm_stm32_gpio.o ./MyLibraries/Src/tm_stm32_gpio.su ./MyLibraries/Src/tm_stm32_gps.cyclo ./MyLibraries/Src/tm_stm32_gps.d ./MyLibraries/Src/tm_stm32_gps.o ./MyLibraries/Src/tm_stm32_gps.su ./MyLibraries/Src/tm_stm32_hd44780.cyclo ./MyLibraries/Src/tm_stm32_hd44780.d ./MyLibraries/Src/tm_stm32_hd44780.o ./MyLibraries/Src/tm_stm32_hd44780.su ./MyLibraries/Src/tm_stm32_i2c.cyclo ./MyLibraries/Src/tm_stm32_i2c.d ./MyLibraries/Src/tm_stm32_i2c.o ./MyLibraries/Src/tm_stm32_i2c.su ./MyLibraries/Src/tm_stm32_i2c_dma.cyclo ./MyLibraries/Src/tm_stm32_i2c_dma.d ./MyLibraries/Src/tm_stm32_i2c_dma.o ./MyLibraries/Src/tm_stm32_i2c_dma.su ./MyLibraries/Src/tm_stm32_id.cyclo ./MyLibraries/Src/tm_stm32_id.d ./MyLibraries/Src/tm_stm32_id.o ./MyLibraries/Src/tm_stm32_id.su ./MyLibraries/Src/tm_stm32_iwdg.cyclo ./MyLibraries/Src/tm_stm32_iwdg.d ./MyLibraries/Src/tm_stm32_iwdg.o ./MyLibraries/Src/tm_stm32_iwdg.su ./MyLibraries/Src/tm_stm32_lcd.cyclo ./MyLibraries/Src/tm_stm32_lcd.d ./MyLibraries/Src/tm_stm32_lcd.o ./MyLibraries/Src/tm_stm32_lcd.su ./MyLibraries/Src/tm_stm32_library_template.cyclo ./MyLibraries/Src/tm_stm32_library_template.d ./MyLibraries/Src/tm_stm32_library_template.o ./MyLibraries/Src/tm_stm32_library_template.su ./MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.cyclo ./MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.d ./MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.o ./MyLibraries/Src/tm_stm32_lis302dl_lis3dsh.su ./MyLibraries/Src/tm_stm32_mpu6050.cyclo ./MyLibraries/Src/tm_stm32_mpu6050.d ./MyLibraries/Src/tm_stm32_mpu6050.o ./MyLibraries/Src/tm_stm32_mpu6050.su ./MyLibraries/Src/tm_stm32_mpu9250.cyclo ./MyLibraries/Src/tm_stm32_mpu9250.d ./MyLibraries/Src/tm_stm32_mpu9250.o ./MyLibraries/Src/tm_stm32_mpu9250.su ./MyLibraries/Src/tm_stm32_nrf24l01.cyclo ./MyLibraries/Src/tm_stm32_nrf24l01.d ./MyLibraries/Src/tm_stm32_nrf24l01.o ./MyLibraries/Src/tm_stm32_nrf24l01.su ./MyLibraries/Src/tm_stm32_onewire.cyclo ./MyLibraries/Src/tm_stm32_onewire.d ./MyLibraries/Src/tm_stm32_onewire.o ./MyLibraries/Src/tm_stm32_onewire.su ./MyLibraries/Src/tm_stm32_pvd.cyclo ./MyLibraries/Src/tm_stm32_pvd.d ./MyLibraries/Src/tm_stm32_pvd.o ./MyLibraries/Src/tm_stm32_pvd.su ./MyLibraries/Src/tm_stm32_qspiflash.cyclo ./MyLibraries/Src/tm_stm32_qspiflash.d ./MyLibraries/Src/tm_stm32_qspiflash.o ./MyLibraries/Src/tm_stm32_qspiflash.su ./MyLibraries/Src/tm_stm32_rcc.cyclo ./MyLibraries/Src/tm_stm32_rcc.d ./MyLibraries/Src/tm_stm32_rcc.o ./MyLibraries/Src/tm_stm32_rcc.su ./MyLibraries/Src/tm_stm32_rng.cyclo ./MyLibraries/Src/tm_stm32_rng.d ./MyLibraries/Src/tm_stm32_rng.o ./MyLibraries/Src/tm_stm32_rng.su ./MyLibraries/Src/tm_stm32_rotary_encoder.cyclo ./MyLibraries/Src/tm_stm32_rotary_encoder.d ./MyLibraries/Src/tm_stm32_rotary_encoder.o ./MyLibraries/Src/tm_stm32_rotary_encoder.su
	-$(RM) ./MyLibraries/Src/tm_stm32_rtc.cyclo ./MyLibraries/Src/tm_stm32_rtc.d ./MyLibraries/Src/tm_stm32_rtc.o ./MyLibraries/Src/tm_stm32_rtc.su ./MyLibraries/Src/tm_stm32_sdram.cyclo ./MyLibraries/Src/tm_stm32_sdram.d ./MyLibraries/Src/tm_stm32_sdram.o ./MyLibraries/Src/tm_stm32_sdram.su ./MyLibraries/Src/tm_stm32_spi.cyclo ./MyLibraries/Src/tm_stm32_spi.d ./MyLibraries/Src/tm_stm32_spi.o ./MyLibraries/Src/tm_stm32_spi.su ./MyLibraries/Src/tm_stm32_spi_dma.cyclo ./MyLibraries/Src/tm_stm32_spi_dma.d ./MyLibraries/Src/tm_stm32_spi_dma.o ./MyLibraries/Src/tm_stm32_spi_dma.su ./MyLibraries/Src/tm_stm32_ssd1306.cyclo ./MyLibraries/Src/tm_stm32_ssd1306.d ./MyLibraries/Src/tm_stm32_ssd1306.o ./MyLibraries/Src/tm_stm32_ssd1306.su ./MyLibraries/Src/tm_stm32_string.cyclo ./MyLibraries/Src/tm_stm32_string.d ./MyLibraries/Src/tm_stm32_string.o ./MyLibraries/Src/tm_stm32_string.su ./MyLibraries/Src/tm_stm32_touch.cyclo ./MyLibraries/Src/tm_stm32_touch.d ./MyLibraries/Src/tm_stm32_touch.o ./MyLibraries/Src/tm_stm32_touch.su ./MyLibraries/Src/tm_stm32_touch_ft5336.cyclo ./MyLibraries/Src/tm_stm32_touch_ft5336.d ./MyLibraries/Src/tm_stm32_touch_ft5336.o ./MyLibraries/Src/tm_stm32_touch_ft5336.su ./MyLibraries/Src/tm_stm32_touch_ts3510.cyclo ./MyLibraries/Src/tm_stm32_touch_ts3510.d ./MyLibraries/Src/tm_stm32_touch_ts3510.o ./MyLibraries/Src/tm_stm32_touch_ts3510.su ./MyLibraries/Src/tm_stm32_usart.cyclo ./MyLibraries/Src/tm_stm32_usart.d ./MyLibraries/Src/tm_stm32_usart.o ./MyLibraries/Src/tm_stm32_usart.su ./MyLibraries/Src/tm_stm32_usart_dma.cyclo ./MyLibraries/Src/tm_stm32_usart_dma.d ./MyLibraries/Src/tm_stm32_usart_dma.o ./MyLibraries/Src/tm_stm32_usart_dma.su ./MyLibraries/Src/tm_stm32_usb.cyclo ./MyLibraries/Src/tm_stm32_usb.d ./MyLibraries/Src/tm_stm32_usb.o ./MyLibraries/Src/tm_stm32_usb.su ./MyLibraries/Src/tm_stm32_usb_device.cyclo ./MyLibraries/Src/tm_stm32_usb_device.d ./MyLibraries/Src/tm_stm32_usb_device.o ./MyLibraries/Src/tm_stm32_usb_device.su ./MyLibraries/Src/tm_stm32_usb_device_cdc.cyclo ./MyLibraries/Src/tm_stm32_usb_device_cdc.d ./MyLibraries/Src/tm_stm32_usb_device_cdc.o ./MyLibraries/Src/tm_stm32_usb_device_cdc.su ./MyLibraries/Src/tm_stm32_usb_device_msc.cyclo ./MyLibraries/Src/tm_stm32_usb_device_msc.d ./MyLibraries/Src/tm_stm32_usb_device_msc.o ./MyLibraries/Src/tm_stm32_usb_device_msc.su ./MyLibraries/Src/tm_stm32_usb_host.cyclo ./MyLibraries/Src/tm_stm32_usb_host.d ./MyLibraries/Src/tm_stm32_usb_host.o ./MyLibraries/Src/tm_stm32_usb_host.su ./MyLibraries/Src/tm_stm32_usb_host_hid.cyclo ./MyLibraries/Src/tm_stm32_usb_host_hid.d ./MyLibraries/Src/tm_stm32_usb_host_hid.o ./MyLibraries/Src/tm_stm32_usb_host_hid.su ./MyLibraries/Src/tm_stm32_usb_host_msc.cyclo ./MyLibraries/Src/tm_stm32_usb_host_msc.d ./MyLibraries/Src/tm_stm32_usb_host_msc.o ./MyLibraries/Src/tm_stm32_usb_host_msc.su

.PHONY: clean-MyLibraries-2f-Src

