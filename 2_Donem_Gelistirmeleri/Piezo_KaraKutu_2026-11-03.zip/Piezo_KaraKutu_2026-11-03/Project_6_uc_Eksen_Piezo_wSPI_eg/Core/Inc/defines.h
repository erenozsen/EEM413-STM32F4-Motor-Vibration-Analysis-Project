/**
 *  Defines for your entire project at one place
 * 
 *	@author 	Tilen Majerle
 *	@email		tilen@majerle.eu
 *	@website	http://stm32f4-discovery.com
 *	@version 	v1.0
 *	@ide		Keil uVision 5
 *	@license	GNU GPL v3
 *	
 * |----------------------------------------------------------------------
 * | Copyright (C) Tilen Majerle, 2014
 * | 
 * | This program is free software: you can redistribute it and/or modify
 * | it under the terms of the GNU General Public License as published by
 * | the Free Software Foundation, either version 3 of the License, or
 * | any later version.
 * |  
 * | This program is distributed in the hope that it will be useful,
 * | but WITHOUT ANY WARRANTY; without even the implied warranty of
 * | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * | GNU General Public License for more details.
 * | 
 * | You should have received a copy of the GNU General Public License
 * | along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * |----------------------------------------------------------------------
 */
#ifndef TM_DEFINES_H
#define TM_DEFINES_H

/* Put your global defines for all libraries here used in your project */
#define FATFS_USE_SDIO 0
#define FATFS_USE_SPI  1

// SD Kartımızın CS pini PA4'te:
#define FATFS_CS_PORT  GPIOA
#define FATFS_CS_PIN   GPIO_PIN_4

// SD kart başlatma (init) sırasında SPI hızı 400 kHz'i geçmemeli (SD standardı).
// 84 MHz / 256 = 328 kHz. Mount başarılı olduktan sonra main.c hızı yükseltir.
#define TM_SPI1_PRESCALER  SPI_BAUDRATEPRESCALER_256

#endif
