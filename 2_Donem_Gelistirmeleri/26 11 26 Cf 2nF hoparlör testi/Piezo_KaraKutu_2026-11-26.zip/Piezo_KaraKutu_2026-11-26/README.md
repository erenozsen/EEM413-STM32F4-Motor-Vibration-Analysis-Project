# Piezo_KaraKutu_2026-11-26

16.11 sürümünden (SPI kapısı açık) farkı yalnız `Core/Src/main.c`:

- Açılışta kayıt kendiliğinden başlamaz; turuncu LED = hazır, mavi buton (PA0) kaydı başlatır/durdurur.
- SD karta `OLAYLAR.TXT` günlüğü: her açılışta reset sebebi (RCC->CSR: POR, BOR, NRST pini, IWDG, WWDG, yazılım),
  kayıt başladı / butonla durduruldu (blok kaybı var/yok), hata sebebi.
- Hata (kırmızı LED) durumunda butona basılırsa SD yeniden bağlanıp yeni kayıt denenir.
- `Recording_Fault()` artık sebep metni alır.

Tüm değişiklikler `USER CODE` blokları içinde (CubeMX yeniden üretiminde korunur).
Derleme: CubeIDE'de projeyi açıp derle (Debug, -O0). Boyut: text 56352, data 308, bss 55564.

Donanım tarafı (bu zip'te kod değil): üç kanalda Cf 470 pF → 2 nF (2 × 1 nF film), anti-alias filtresi
~2,6 nF (~2,8 kHz). Ayrıntı klasördeki README.md'de.
