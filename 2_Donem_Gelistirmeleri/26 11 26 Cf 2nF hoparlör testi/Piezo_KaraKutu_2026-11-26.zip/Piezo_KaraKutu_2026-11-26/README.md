# Piezo_KaraKutu_2026-11-26

16.11 sürümünden (SPI kapısı açık) farkı yalnız `Core/Src/main.c`:

- Açılışta kayıt kendiliğinden başlamaz; turuncu LED = hazır, mavi buton (PA0) kaydı başlatır/durdurur.
- SD karta `OLAYLAR.TXT` günlüğü: her açılışta reset sebebi (RCC->CSR: POR, BOR, NRST pini, IWDG, WWDG, yazılım),
  kayıt başladı / butonla durduruldu (blok kaybı var/yok), hata sebebi ve hangi SD işleminin hangi FatFs koduyla
  bozulduğu (ör. `f_sync FR=1`).
- Hata olunca kırmızı LED hata kodu kadar yanıp söner (1 SD bağlanamadı, 2 SD yazma/kart dolu, 3 ADC/DMA,
  4 ADC durdu, 5 dosya açılamadı/kapatılamadı); yeşil yanarken sabit kırmızı = veri kaybı.
- Hata satırı yazılamazsa SD iki kez yeniden bağlanıp tekrar denenir; açılışta SD üç kez denenir.
- Hatadan sonra butona basılırsa SD yeniden bağlanıp yeni kayıt başlatılır.

Tüm değişiklikler `USER CODE` blokları içinde (CubeMX yeniden üretiminde korunur).
Derleme: CubeIDE'de projeyi açıp derle (Debug, -O0). Boyut: text 57380, data 308, bss 55716.

Donanım tarafı (bu zip'te kod değil): üç kanalda Cf 470 pF → 2 nF (2 × 1 nF film), anti-alias filtresi
~2,6 nF (~2,8 kHz). Ayrıntı klasördeki README.md'de.
