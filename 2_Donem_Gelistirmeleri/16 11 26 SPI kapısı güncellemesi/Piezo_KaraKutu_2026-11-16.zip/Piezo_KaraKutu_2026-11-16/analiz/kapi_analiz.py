# -*- coding: utf-8 -*-
# SPI kapisi testi kayitlarini inceler. Kayitlara ve analiz.py'ye yazmaz.
# Kullanim: python -I kapi_analiz.py dosya1.BIN [dosya2.BIN ...]
import importlib.util
import sys
from pathlib import Path

import numpy as np
from scipy.signal import medfilt

sys.stdout.reconfigure(encoding="utf-8")
spec = importlib.util.spec_from_file_location("an", Path(__file__).resolve().parent / "analiz.py")
an = importlib.util.module_from_spec(spec)
spec.loader.exec_module(an)
P, SAKIN, FS = an.P, an.SAKIN, an.FS
KOK = an.KOK.parent / "16 11 26 SPI kapısı güncellemesi" / "kayitlar"  # depo duzeninde 16.11 kayitlari
CIZ = Path(sys.argv[0]).resolve().parent


def pencere_olcu(x, idx):
    """Bloklar uzerinde ortalama |r| profili; aktif sure ve aktif ici ortalama."""
    r = np.abs(x - medfilt(x, 7))
    M = np.array([r[k * P: k * P + SAKIN] for k in idx])
    sak = np.concatenate([r[k * P + SAKIN: (k + 1) * P] for k in idx]).mean()
    prof = np.convolve(M.mean(axis=0), np.ones(20) / 20, mode="same")
    tepe = np.percentile(prof[20:350], 50)
    akt = np.nonzero(prof > sak + 0.25 * (tepe - sak))[0]
    son = int(akt[akt < 950].max()) if len(akt) else 0
    ici = float(M[:, :son].mean()) if son else float("nan")
    # blok basina aktif sure (tek blok, kaba)
    sureler = []
    for row in M:
        pr = np.convolve(row, np.ones(40) / 40, mode="same")
        a = np.nonzero(pr > sak + 0.25 * (tepe - sak))[0]
        sureler.append(a[a < 950].max() / 10 if len(a) else 0)
    return sak, son / 10, ici, np.array(sureler), {w: float(M[:, :w].mean()) for w in (450, 700, 900)}


for ad in sys.argv[1:]:
    yol = KOK / ad
    v, artik = an.oku(yol)
    nb = v.shape[1] // P
    idx = an.sessiz_bloklar(v)
    print(f"\n===== {ad}: {yol.stat().st_size} bayt, {v.shape[1]/FS:.1f} s, {nb} blok, sessiz {len(idx)} {idx[:6]}...{idx[-4:]}, artik {artik}")
    # 1 s'lik RMS zarfi (kanal basina), sessiz/ton bolumlerini gormek icin
    w = FS
    for c, n in enumerate("XYZ"):
        x = v[c]
        zarf = [x[i:i + w].std() for i in range(0, len(x) - w + 1, w)]
        pp, _ = an.yavas_darbe_pp(x, idx)
        sak, T, ici, sureler, cat = pencere_olcu(x, idx)
        b = an.bant_rms(x, idx)
        dk = an.donma_kirpilma(x)
        print(f" {n}: orta {np.median(x):6.0f} ({np.median(x)*an.VDD/4095:.3f} V) min {x.min():.0f} maks {x.max():.0f} alt {dk['alt']} ust {dk['ust']} don {len(dk['donmus_pencere_s'])} sic {dk['ani_sicrama']}")
        print(f"    darbe {pp if pp is None else round(pp,1)} | cat450 {cat[450]:.1f} cat700 {cat[700]:.1f} cat900 {cat[900]:.1f} sakin {sak:.2f} | aktif ~{T:.0f} ms, aktif ici {ici:.1f}, blok sure medyan {np.median(sureler):.0f} p90 {np.percentile(sureler,90):.0f} maks {sureler.max():.0f} ms")
        print(f"    bant 1-45 {b['1-45']:.1f} 47-53 {b['47-53']:.1f} 53-500 {b['53-500']:.1f} 500-5k {b['500-5000']:.1f}")
        print("    1s std zarfi:", " ".join(f"{z:.0f}" for z in zarf))
    if "100hz" in ad.lower():
        for pen in (450, 900):
            an.PENCERE = pen
            for c, n in enumerate("XYZ"):
                try:
                    f = an.faz_testi(v[c])
                    print(f" faz {n} PENCERE {pen}: f0 {f['f0']:.3f} sinir {f['sinir_sayisi']} maks {f['maks_abs_rad']:.3f} ort {f['ort_abs_rad']:.3f} ton {f['ton_baslangic_s']:.1f}-{f['ton_bitis_s']:.1f} s, kayip beklenen {f['bir_blok_kayipta_beklenen_atlama_rad']:.3f}")
                except Exception as e:
                    print(f" faz {n}: hata {e!r}")
        an.PENCERE = 450
        # 100 Hz genliği kanal basina (ton bolumu)
        for c, n in enumerate("XYZ"):
            x = v[c]
            t = np.arange(len(x)) / FS
            seg = []
            for k in range(nb):
                s = x[k * P + SAKIN:(k + 1) * P]
                tt = t[k * P + SAKIN:(k + 1) * P]
                seg.append(abs(np.sum((s - s.mean()) * np.exp(-2j * np.pi * 100 * tt))) * 2 / len(s))
            seg = np.array(seg)
            print(f" 100 Hz genlik {n}: maks blok {seg.max():.1f} LSB, medyan aktif {np.median(seg[seg > 0.5*seg.max()]):.1f} LSB, aktif blok {int((seg > 0.5*seg.max()).sum())}")

    # Hizli gorsel: ham sinyal + bir blogun ilk 100 ms'si
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(4, 1, figsize=(13, 10))
    t = np.arange(v.shape[1]) / FS
    for c, n in enumerate("XYZ"):
        ax[c].plot(t, v[c], lw=0.3)
        ax[c].set_ylabel(n)
    k = idx[len(idx) // 2] if idx else 1
    for c, n in enumerate("XYZ"):
        s = v[c, k * P: k * P + 1200]
        ax[3].plot(np.arange(len(s)) / 10, s - np.median(s) + c * 60, lw=0.6, label=n)
    ax[3].set_xlabel(f"blok {k} ici ms"); ax[3].legend()
    fig.tight_layout(); fig.savefig(CIZ / (Path(ad).stem + ".png"), dpi=80); plt.close(fig)
