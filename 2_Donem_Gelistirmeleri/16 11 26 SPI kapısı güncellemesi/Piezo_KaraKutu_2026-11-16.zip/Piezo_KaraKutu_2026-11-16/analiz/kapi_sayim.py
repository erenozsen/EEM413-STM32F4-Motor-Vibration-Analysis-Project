# -*- coding: utf-8 -*-
# Yazma penceresindeki sicrama sayisi ve yuzdelikler: gate 0 / gate 1. Kayitlara yazmaz.
import importlib.util
import sys
from pathlib import Path

import numpy as np
from scipy.signal import medfilt

sys.stdout.reconfigure(encoding="utf-8")
spec = importlib.util.spec_from_file_location("an", Path(__file__).resolve().parent / "analiz.py")
an = importlib.util.module_from_spec(spec)
spec.loader.exec_module(an)
P, SAKIN = an.P, an.SAKIN
KOK = an.KOK.parent / "16 11 26 SPI kapısı güncellemesi" / "kayitlar"  # depo duzeninde 16.11 kayitlari
OUT = Path(sys.argv[0]).resolve().parent
DOSYA = ["gate0swPIEZO001.BIN", "gate1swPIEZO003.BIN", "gate0swPIEZO005.BIN",
         "gate0100hzPIEZO002.BIN", "gate1100hzPIEZO004.BIN", "gate0100hzPIEZO006.BIN"]

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
fig, ax = plt.subplots(3, 1, figsize=(12, 8), sharex=True)
for ad in DOSYA:
    v, _ = an.oku(KOK / ad)
    idx = an.sessiz_bloklar(v)
    satir = []
    for c, n in enumerate("XYZ"):
        r = np.abs(v[c] - medfilt(v[c], 7))
        W = np.concatenate([r[k * P: k * P + 900] for k in idx])
        S = np.concatenate([r[k * P + SAKIN: k * P + SAKIN + 900] for k in idx])
        # ayni uzunlukta sakin parcayla karsilastir
        satir.append(f"{n}: >15 pencere/sakin {int((W > 15).sum())}/{int((S > 15).sum())}  "
                     f"p99 {np.percentile(W,99):.1f}/{np.percentile(S,99):.1f}  maks {W.max():.0f}/{S.max():.0f}")
        if "sw" in ad:
            prof = np.array([r[k * P: k * P + 1200] for k in idx]).mean(axis=0)
            ax[c].plot(np.arange(1200) / 10, np.convolve(prof, np.ones(10) / 10, mode="same"),
                       lw=0.8, label=ad.replace("PIEZO", " ").replace(".BIN", ""))
            ax[c].set_ylabel(f"{n} ort |r| (LSB)")
    print(f"{ad} ({len(idx)} sessiz blok)\n   " + "\n   ".join(satir))
ax[0].legend(); ax[2].set_xlabel("blok basindan ms (yazma 0'da baslar)")
fig.tight_layout(); fig.savefig(OUT / "kapi_profil.png", dpi=90)
