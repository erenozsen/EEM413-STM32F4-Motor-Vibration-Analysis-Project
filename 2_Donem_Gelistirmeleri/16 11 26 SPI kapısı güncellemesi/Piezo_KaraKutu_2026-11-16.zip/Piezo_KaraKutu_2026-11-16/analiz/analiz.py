# -*- coding: utf-8 -*-
# Rapor sayilarini .BIN kayitlarindan yeniden hesaplar. Kayitlara yazmaz, yalniz okur.
# Calistirma: python -I analiz.py (numpy, scipy gerekir)
# Cikti: ayni klasorde sonuclar.json + ekrana tablo.
import json
from pathlib import Path

import numpy as np
from scipy.signal import medfilt, welch

KOK = Path(r"C:\ST\claude\VsCodeda_Piezo_Ornek_ve_Analiz")
CIKTI = Path(__file__).resolve().parent
FS = 10_000
P = 4096                # blok k, frame 4096*k'da baslar
VDD = 2.936
LSB_MV = VDD / 4095 * 1000
PENCERE = 450           # yazma penceresi (blok ici ornek)
SAKIN = 1000            # sakin bolum baslangici (blok ici ornek)
KANAL = "XYZ"
BANTLAR = {"1-45": (1, 45), "47-53": (47, 53), "53-500": (53, 500), "500-5000": (500, 5000)}

KAYITLAR = [
    ("18.10", "sessiz", "18.10.26/sonPIEZO3.BIN"),
    ("18.10", "100 Hz", "18.10.26/Yenideneme 100hz_PIEZO001.BIN"),
    ("18.10", "sweep", "18.10.26/yenisweepPIEZO3.BIN"),
    ("21.10", "iyilehim", "21 10 26 kapasitör ve topraklama/PIEZOiyilehimX.BIN"),
    ("21.10", "kotulehim", "21 10 26 kapasitör ve topraklama/PIEZOkötülehimX.BIN"),
    ("21.10", "sari", "21 10 26 kapasitör ve topraklama/PIEZOsarıX.BIN"),
    ("01.11", "PIEZO001", "01 11 26 blendajlı piezo Y ekseni/PIEZO001.BIN"),
    ("01.11", "PIEZO002", "01 11 26 blendajlı piezo Y ekseni/PIEZO002.BIN"),
    ("01.11", "PIEZO003", "01 11 26 blendajlı piezo Y ekseni/PIEZO003.BIN"),
    ("01.11", "PIEZO004", "01 11 26 blendajlı piezo Y ekseni/PIEZO004.BIN"),
    ("01.11", "PIEZO005", "01 11 26 blendajlı piezo Y ekseni/PIEZO005.BIN"),
]


def oku(yol):
    d = np.fromfile(yol, dtype=np.uint16)
    n = len(d) // 3
    return d[: 3 * n].reshape(-1, 3).T.astype(float), len(d) % 3


def bloklar(x):
    return [x[k * P: (k + 1) * P] for k in range(len(x) // P)]


def sessiz_bloklar(v):
    """Blok 0 haric; X ve Y blok std < 2,5 x medyan (sakin bolumde)."""
    nb = v.shape[1] // P
    if nb < 2:
        return []
    s = {c: np.array([v[c, k * P + SAKIN: (k + 1) * P].std() for k in range(nb)]) for c in (0, 1)}
    m = {c: np.median(s[c][1:]) for c in (0, 1)}
    return [k for k in range(1, nb) if s[0][k] < 2.5 * m[0] and s[1][k] < 2.5 * m[1]]


def yavas_darbe_pp(x, idx):
    """Her bloktan kendi 1000+ medyani cikar, bloklar uzerinde medyan, 16 ornek duzelt, 0-700 p-p."""
    if len(idx) < 3:
        return None, None
    b = np.array([x[k * P: (k + 1) * P] - np.median(x[k * P + SAKIN: (k + 1) * P]) for k in idx])
    t = np.median(b, axis=0)
    t = np.convolve(t, np.ones(16) / 16, mode="same")
    return float(t[8:700].max() - t[8:700].min()), t


def catirti(x, idx):
    """r = x - medfilt(x,7); ort |r| yazma penceresi / sakin bolum."""
    if not idx:
        return None, None
    r = np.abs(x - medfilt(x, 7))
    a = np.concatenate([r[k * P: k * P + PENCERE] for k in idx])
    b = np.concatenate([r[k * P + SAKIN: (k + 1) * P] for k in idx])
    return float(a.mean()), float(b.mean())


def bant_rms(x, idx):
    """Sessiz bloklarin 1000+ ornekleri, blok basina welch, PSD ortalamasi, banttan RMS."""
    if not idx:
        return {}
    psd = []
    for k in idx:
        f, p = welch(x[k * P + SAKIN: (k + 1) * P], fs=FS, nperseg=P - SAKIN, detrend="constant")
        psd.append(p)
    p = np.mean(psd, axis=0)
    df = f[1] - f[0]
    return {ad: float(np.sqrt(p[(f >= a) & (f <= b)].sum() * df)) for ad, (a, b) in BANTLAR.items()}


def donma_kirpilma(x):
    alt = int((x <= 2).sum())
    ust = int((x >= 4093).sum())
    w = int(0.2 * FS)
    orta = np.median(x)
    don = []
    for i in range(0, len(x) - w, w):
        s = x[i: i + w]
        if s.std() < 5 and abs(s.mean() - orta) > 100:
            don.append(round(i / FS, 2))
    return {"alt": alt, "ust": ust, "donmus_pencere_s": don, "ani_sicrama": int((np.abs(np.diff(x)) > 1000).sum())}


def yazma_suresi_ms(x, idx):
    r = np.abs(x - medfilt(x, 7))
    t = []
    for k in idx:
        w = np.nonzero(r[k * P: k * P + 1000] > 30)[0]
        if len(w):
            t.append(w[-1] / FS * 1000)
    return t


def faz_testi(x, f0=None):
    """Ton varken blok sinirlarinda faz surekliligi. Pencereler bozuk ilk 450 ornegin disinda."""
    nb = len(x) // P
    # Tonu bloklarin sakin bolumunde tespit et
    def bilesen(seg, f, t0):
        t = (np.arange(len(seg)) + t0) / FS
        seg = seg - seg.mean()
        return np.sum(seg * np.exp(-2j * np.pi * f * t)) * 2 / len(seg)
    grid = np.arange(95, 105, 0.002)
    enr = []
    for k in range(nb):
        seg = x[k * P + SAKIN: (k + 1) * P]
        enr.append(abs(bilesen(seg, 100.0, 0)))
    enr = np.array(enr)
    aktif = np.nonzero(enr > 0.5 * np.percentile(enr, 90))[0]
    # ardisik en uzun aktif blok dizisi
    grup, en = [aktif[0]], [aktif[0]]
    for a in aktif[1:]:
        grup = grup + [a] if a == grup[-1] + 1 else [a]
        if len(grup) > len(en):
            en = grup
    ilk, son = en[0] + 1, en[-1] - 1   # gecis bloklarini atla
    t0 = [k * P + SAKIN for k in range(ilk, son + 1)]
    seg = [x[t: t + P - SAKIN] for t in t0]
    # f0: tum sakin bolumlerin faz egiminden
    if f0 is None:
        faz = np.unwrap([np.angle(bilesen(s, 100.0, t)) for s, t in zip(seg, t0)])
        f0 = 100.0 + np.polyfit(np.array(t0) / FS, faz, 1)[0] / (2 * np.pi)
    # sinir oncesi ve sonrasi 30 ms pencereler (sinirin 450 ornek sonrasi = bozuk bolum disi)
    W = 300
    fark = []
    for k in range(ilk + 1, son + 1):
        o = k * P - W
        s = k * P + PENCERE
        a = np.angle(bilesen(x[o: o + W], f0, o))
        b = np.angle(bilesen(x[s: s + W], f0, s))
        fark.append(float(np.angle(np.exp(1j * (b - a)))))
    atlama_tek_blok = float(np.angle(np.exp(2j * np.pi * f0 * P / FS)))
    return {
        "f0": float(f0), "sinir_sayisi": len(fark), "maks_abs_rad": float(np.max(np.abs(fark))),
        "ort_abs_rad": float(np.mean(np.abs(fark))),
        "ton_baslangic_s": ilk * P / FS, "ton_bitis_s": (son + 1) * P / FS,
        "bir_blok_kayipta_beklenen_atlama_rad": atlama_tek_blok,
    }


def main():
    sonuc = {}
    sablon = {}
    for tarih, ad, gor in KAYITLAR:
        yol = KOK / gor
        v, artik = oku(yol)
        idx = sessiz_bloklar(v)
        nb = v.shape[1] // P
        d = {"tarih": tarih, "dosya": gor, "bayt": yol.stat().st_size, "artik_ornek": artik,
             "sure_s": v.shape[1] / FS, "blok": nb, "sessiz_blok": len(idx), "kanal": {}}
        for c in range(3):
            x = v[c]
            pp, t = yavas_darbe_pp(x, idx)
            cat_a, cat_b = catirti(x, idx)
            sak = np.concatenate([x[k * P + SAKIN: (k + 1) * P] for k in idx]) if idx else x
            d["kanal"][KANAL[c]] = {
                "darbe_pp": pp, "catirti_yazma": cat_a, "catirti_sakin": cat_b,
                "bant": bant_rms(x, idx),
                "orta_nokta": float(np.median(sak)), "orta_nokta_V": float(np.median(sak) * VDD / 4095),
                "tum_std": float(x.std()), "sakin_std": float(sak.std()),
                **donma_kirpilma(x),
            }
            if t is not None:
                sablon[(tarih, ad, KANAL[c])] = t
        sonuc[f"{tarih} {ad}"] = d

    # 18.10 yazma suresi (sessiz kayit, X kanali catirtisi en belirgin)
    v, _ = oku(KOK / "18.10.26/sonPIEZO3.BIN")
    idx = sessiz_bloklar(v)
    t = yazma_suresi_ms(v[0], idx)
    sonuc["yazma_suresi_18.10_sessiz"] = {
        "n": len(t), "medyan_ms": float(np.median(t)), "min_ms": float(np.min(t)), "maks_ms": float(np.max(t)),
        "p90_ms": float(np.percentile(t, 90)), "degerler": [round(a, 1) for a in t]}
    v, _ = oku(KOK / "18.10.26/Yenideneme 100hz_PIEZO001.BIN")
    sonuc["faz_testi_100hz"] = {c: faz_testi(v[i]) for i, c in enumerate(KANAL)}

    (CIKTI / "sonuclar.json").write_text(json.dumps(sonuc, ensure_ascii=False, indent=1), encoding="utf-8")
    np.savez(CIKTI / "sablonlar.npz", **{"|".join(k): v for k, v in sablon.items()})

    # Ekran tablosu
    print(f"LSB = {LSB_MV:.3f} mV")
    for ad, d in sonuc.items():
        if "kanal" not in d:
            continue
        print(f"\n== {ad}  {d['sure_s']:.1f} s, {d['blok']} blok, sessiz {d['sessiz_blok']}, artik {d['artik_ornek']}")
        for c, k in d["kanal"].items():
            f = lambda x: "  --" if x is None else f"{x:6.1f}"
            b = k["bant"]
            print(f" {c} orta {k['orta_nokta']:6.0f} ({k['orta_nokta_V']:.3f} V) darbe {f(k['darbe_pp'])}"
                  f" cat {f(k['catirti_yazma'])}/{f(k['catirti_sakin'])}"
                  f" 1-45 {f(b.get('1-45'))} 47-53 {f(b.get('47-53'))} 53-500 {f(b.get('53-500'))}"
                  f" 500-5k {f(b.get('500-5000'))} std {k['tum_std']:6.1f} sak {k['sakin_std']:6.1f}"
                  f" alt {k['alt']} ust {k['ust']} sic {k['ani_sicrama']} don {len(k['donmus_pencere_s'])}"
                  f" {k['donmus_pencere_s'][:3]}{'...' if len(k['donmus_pencere_s'])>3 else ''}")
    y = sonuc["yazma_suresi_18.10_sessiz"]
    print("\nyazma suresi 18.10 sessiz:", {k: v for k, v in y.items() if k != "degerler"})
    print("faz testi:", json.dumps(sonuc["faz_testi_100hz"], indent=0))


if __name__ == "__main__":
    main()
